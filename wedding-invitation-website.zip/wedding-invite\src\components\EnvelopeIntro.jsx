// =====================================================
// EnvelopeIntro.jsx — Opening card animation screen
// =====================================================
import { useState, useEffect } from "react";
import { FloralCorner, OmSymbol, Mandala } from "./DecorativeElements";
import { COUPLE } from "../weddingData";

export default function EnvelopeIntro({ onComplete }) {
  const [stage, setStage] = useState("idle"); // idle → tapping → open → rising → done
  const [showTapHint, setShowTapHint] = useState(false);

  useEffect(() => {
    // Show tap hint after 1.2s
    const t1 = setTimeout(() => setShowTapHint(true), 1200);
    return () => clearTimeout(t1);
  }, []);

  const handleOpen = () => {
    if (stage !== "idle") return;
    setStage("tapping");
    setTimeout(() => setStage("open"), 200);
    setTimeout(() => setStage("rising"), 1400);
    setTimeout(() => setStage("done"), 2800);
    setTimeout(() => onComplete(), 3200);
  };

  return (
    <div
      className="loading-overlay"
      style={{
        background: "radial-gradient(ellipse at center, #0f2418 0%, #091a10 100%)",
        cursor: stage === "idle" ? "pointer" : "default",
      }}
      onClick={handleOpen}
    >
      {/* Floating mandala background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
        <Mandala size={500} color="#faf3e0" goldColor="#d4a017" />
      </div>

      {/* Floating particles */}
      {[...Array(12)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: `${4 + (i % 3) * 3}px`,
            height: `${4 + (i % 3) * 3}px`,
            background: "rgba(212,160,23,0.4)",
            left: `${10 + i * 7}%`,
            top: `${15 + (i % 5) * 15}%`,
            animation: `float ${5 + i * 0.5}s ease-in-out infinite`,
            animationDelay: `${i * 0.4}s`,
          }}
        />
      ))}

      {/* Main envelope card */}
      <div
        className="envelope-wrapper relative"
        style={{
          opacity: stage === "done" ? 0 : 1,
          transform: stage === "rising" || stage === "done" ? "translateY(-80px) scale(0.9)" : "translateY(0) scale(1)",
          transition: "opacity 0.8s ease, transform 1s ease",
        }}
      >
        {/* Envelope body */}
        <div
          className="relative mx-4"
          style={{
            width: "min(380px, 90vw)",
            background: "#faf3e0",
            borderRadius: "4px",
            border: "2.5px solid #1a3a2a",
            boxShadow:
              "inset 0 0 0 4px #faf3e0, inset 0 0 0 5.5px rgba(212,160,23,0.5), inset 0 0 0 7px #faf3e0, 0 30px 80px rgba(0,0,0,0.5), 0 10px 30px rgba(0,0,0,0.3)",
          }}
        >
          {/* Flap (animated open) */}
          <div
            className="envelope-flap"
            style={{
              transform: stage === "open" || stage === "rising" || stage === "done"
                ? "rotateX(-180deg)" : "rotateX(0deg)",
              position: "relative",
              zIndex: 10,
            }}
          >
            <div
              style={{
                background: "#f5ebd0",
                padding: "0",
                height: "0",
                borderLeft: `min(190px, 45vw) solid transparent`,
                borderRight: `min(190px, 45vw) solid transparent`,
                borderTop: `min(130px, 30vw) solid #f0e0b8`,
                borderBottom: "none",
                borderTopLeftRadius: "4px",
                borderTopRightRadius: "4px",
                filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.1))",
              }}
            />
            {/* Flap seal */}
            <div
              className="absolute"
              style={{
                top: "10px",
                left: "50%",
                transform: "translateX(-50%)",
                zIndex: 11,
              }}
            >
              <div
                style={{
                  width: "56px",
                  height: "56px",
                  borderRadius: "50%",
                  background: "linear-gradient(135deg, #d4a017, #f5d78e, #b8860b)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 2px 12px rgba(212,160,23,0.4)",
                  border: "1.5px solid rgba(26,58,42,0.3)",
                }}
              >
                <OmSymbol size={32} color="#1a3a2a" />
              </div>
            </div>
          </div>

          {/* Envelope interior / card reveal */}
          <div
            style={{
              padding: "28px 24px",
              minHeight: "240px",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Corners */}
            <div className="absolute top-0 left-0 opacity-60"><FloralCorner size={50} /></div>
            <div className="absolute top-0 right-0 opacity-60" style={{ transform: "scaleX(-1)" }}><FloralCorner size={50} /></div>
            <div className="absolute bottom-0 left-0 opacity-60" style={{ transform: "scaleY(-1)" }}><FloralCorner size={50} /></div>
            <div className="absolute bottom-0 right-0 opacity-60" style={{ transform: "scale(-1)" }}><FloralCorner size={50} /></div>

            {/* Card content */}
            <div className="text-center py-4">
              {/* Om */}
              <div className="flex justify-center mb-3">
                <OmSymbol size={36} color="#d4a017" />
              </div>

              {/* Sanskrit blessing */}
              <p
                style={{
                  fontFamily: "Noto Serif Devanagari, serif",
                  fontSize: "clamp(11px, 2.5vw, 13px)",
                  color: "rgba(26,58,42,0.6)",
                  letterSpacing: "0.15em",
                  marginBottom: "12px",
                }}
              >
                शुभ विवाह
              </p>

              {/* Couple names */}
              <h1
                style={{
                  fontFamily: "Playfair Display, serif",
                  fontSize: "clamp(20px, 5.5vw, 30px)",
                  fontWeight: 400,
                  color: "#0f2418",
                  lineHeight: 1.1,
                  marginBottom: "4px",
                }}
              >
                {COUPLE.groom}
              </h1>
              <div
                style={{
                  fontFamily: "Cormorant Garamond, serif",
                  fontSize: "clamp(13px, 3vw, 16px)",
                  color: "rgba(212,160,23,0.8)",
                  letterSpacing: "0.2em",
                  marginBottom: "4px",
                }}
              >
                &amp;
              </div>
              <h1
                style={{
                  fontFamily: "Playfair Display, serif",
                  fontSize: "clamp(20px, 5.5vw, 30px)",
                  fontWeight: 400,
                  color: "#0f2418",
                  lineHeight: 1.1,
                  marginBottom: "16px",
                }}
              >
                {COUPLE.bride}
              </h1>

              {/* Date */}
              <p
                style={{
                  fontFamily: "Cormorant Garamond, serif",
                  fontSize: "clamp(11px, 2.8vw, 13px)",
                  color: "rgba(26,58,42,0.65)",
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                }}
              >
                {COUPLE.weddingDate}
              </p>
            </div>
          </div>

          {/* Envelope bottom fold lines */}
          <div
            style={{
              position: "absolute",
              bottom: 0,
              left: 0,
              right: 0,
              height: "0",
              borderLeft: `min(190px, 45vw) solid transparent`,
              borderRight: `min(190px, 45vw) solid transparent`,
              borderBottom: `min(80px, 18vw) solid rgba(240,224,184,0.6)`,
            }}
          />
        </div>

        {/* Tap to open hint */}
        <div
          className="text-center mt-8 transition-all duration-700"
          style={{
            opacity: showTapHint && stage === "idle" ? 1 : 0,
            transform: showTapHint ? "translateY(0)" : "translateY(10px)",
          }}
        >
          <div
            className="animate-gold-pulse"
            style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "13px",
              color: "rgba(212,160,23,0.75)",
              letterSpacing: "0.25em",
              textTransform: "uppercase",
            }}
          >
            ✦ Tap to Open ✦
          </div>
        </div>
      </div>
    </div>
  );
}
