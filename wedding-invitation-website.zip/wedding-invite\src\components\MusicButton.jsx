// =====================================================
// MusicButton.jsx — Floating mute/unmute button
// =====================================================
import { useState, useEffect } from "react";

export default function MusicButton({ audioRef, isPlaying, setIsPlaying }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 1000);
    return () => clearTimeout(t);
  }, []);

  const toggleMusic = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch((err) => console.log("Play failed:", err));
    }
  };

  // Musical note SVG bars (animated when playing)
  const MusicIcon = () => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
      {isPlaying ? (
        <>
          {/* Bars dancing */}
          <rect x="2" y="8" width="3" height="7" rx="1.5" fill="#faf3e0" opacity="0.9">
            <animate attributeName="height" values="7;10;5;9;7" dur="0.8s" repeatCount="indefinite"/>
            <animate attributeName="y" values="8;5;10;6;8" dur="0.8s" repeatCount="indefinite"/>
          </rect>
          <rect x="7" y="5" width="3" height="10" rx="1.5" fill="#faf3e0" opacity="0.9">
            <animate attributeName="height" values="10;6;12;8;10" dur="0.9s" repeatCount="indefinite"/>
            <animate attributeName="y" values="5;9;3;7;5" dur="0.9s" repeatCount="indefinite"/>
          </rect>
          <rect x="12" y="6" width="3" height="9" rx="1.5" fill="#faf3e0" opacity="0.9">
            <animate attributeName="height" values="9;12;6;10;9" dur="0.7s" repeatCount="indefinite"/>
            <animate attributeName="y" values="6;3;9;5;6" dur="0.7s" repeatCount="indefinite"/>
          </rect>
        </>
      ) : (
        // Muted icon
        <>
          <path d="M9 2L5 6H2v6h3l4 4V2z" stroke="#faf3e0" strokeWidth="1.2" fill="none"/>
          <line x1="13" y1="5" x2="16" y2="13" stroke="#faf3e0" strokeWidth="1.5" strokeLinecap="round"/>
          <line x1="16" y1="5" x2="13" y2="13" stroke="#faf3e0" strokeWidth="1.5" strokeLinecap="round"/>
        </>
      )}
    </svg>
  );

  return (
    <div
      className="fixed z-50 transition-all duration-500"
      style={{
        top: "16px",
        right: "16px",
        opacity: visible ? 1 : 0,
        transform: visible ? "scale(1)" : "scale(0)",
      }}
    >
      <button
        className="music-btn"
        onClick={toggleMusic}
        aria-label={isPlaying ? "Mute music" : "Play music"}
        title={isPlaying ? "Mute music" : "Play music"}
      >
        <MusicIcon />
      </button>
      {/* Ripple when playing */}
      {isPlaying && (
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            border: "2px solid rgba(212,160,23,0.4)",
            animation: "ping 1.5s cubic-bezier(0,0,0.2,1) infinite",
          }}
        />
      )}
    </div>
  );
}

