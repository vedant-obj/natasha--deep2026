// =====================================================
// CoupleSection.jsx — Bride & Groom intro section
// =====================================================
import { useEffect, useRef } from "react";
import { FloralCorner, LotusDivider, Elephant, BananaLeaf } from "./DecorativeElements";
import { COUPLE } from "../weddingData";

// ── Photo placeholder ─────────────────────────────────────────────
const PhotoPlaceholder = ({ label, isGroom }) => (
  <div
    className="relative mx-auto"
    style={{
      width: "clamp(140px, 35vw, 200px)",
      height: "clamp(170px, 42vw, 240px)",
    }}
  >
    {/* Frame */}
    <div
      style={{
        position: "absolute",
        inset: 0,
        border: "2.5px solid #1a3a2a",
        borderRadius: "3px",
        boxShadow: "inset 0 0 0 3px #faf3e0, inset 0 0 0 4.5px rgba(212,160,23,0.4), inset 0 0 0 6px #faf3e0, 0 8px 30px rgba(26,58,42,0.12)",
        background: "#f5ebd0",
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='200' height='200' filter='url(%23n)' opacity='0.05'/%3E%3C/svg%3E")`,
      }}
    >
      {/* Corners */}
      <div className="absolute top-0 left-0"><FloralCorner size={34} /></div>
      <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={34} /></div>
      <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={34} /></div>
      <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={34} /></div>

      {/* Placeholder content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
        <div
          style={{
            width: "60px",
            height: "60px",
            borderRadius: "50%",
            background: "rgba(26,58,42,0.08)",
            border: "1.5px dashed rgba(212,160,23,0.4)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
            <circle cx="14" cy="10" r="5" stroke="rgba(26,58,42,0.3)" strokeWidth="1.5"/>
            <path d="M4 24 C4 18 24 18 24 24" stroke="rgba(26,58,42,0.3)" strokeWidth="1.5" fill="none"/>
          </svg>
        </div>
        <p style={{
          fontFamily: "Cormorant Garamond, serif",
          fontSize: "10px",
          color: "rgba(26,58,42,0.35)",
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          textAlign: "center",
          padding: "0 12px",
        }}>
          {/* ✏️ EDIT: Replace with <img> tag for actual photo */}
          Add Photo
        </p>
      </div>
    </div>
  </div>
);

// ── Card for each person ──────────────────────────────────────────
const PersonCard = ({ name, fullName, familyDesc, isGroom, delay }) => (
  <div
    className="scroll-reveal flex flex-col items-center text-center"
    style={{ animationDelay: delay, flex: "1 1 280px" }}
  >
    <PhotoPlaceholder isGroom={isGroom} />
    <div className="mt-5">
      <p style={{
        fontFamily: "Cormorant Garamond, serif",
        fontSize: "11px",
        letterSpacing: "0.3em",
        color: "rgba(26,58,42,0.45)",
        textTransform: "uppercase",
        marginBottom: "6px",
      }}>
        {isGroom ? "The Groom" : "The Bride"}
      </p>
      <h2 style={{
        fontFamily: "Playfair Display, serif",
        fontStyle: "italic",
        fontSize: "clamp(24px, 5.5vw, 36px)",
        fontWeight: 400,
        color: "#0f2418",
        marginBottom: "4px",
      }}>
        {name}
      </h2>
      <p style={{
        fontFamily: "EB Garamond, serif",
        fontSize: "clamp(12px, 2.8vw, 14px)",
        color: "rgba(26,58,42,0.55)",
        letterSpacing: "0.03em",
        lineHeight: 1.5,
        maxWidth: "220px",
        margin: "0 auto",
      }}>
        {familyDesc}
      </p>
    </div>
  </div>
);

// ── Main Section ──────────────────────────────────────────────────
export default function CoupleSection() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal, .scroll-reveal-left, .scroll-reveal-right");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.12 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="couple"
      className="relative py-20 px-4 paper-texture overflow-hidden"
    >
      {/* Side banana leaves */}
      <div className="absolute left-0 top-1/4 opacity-15 pointer-events-none hidden lg:block animate-float" style={{ animationDelay: "1.5s" }}>
        <BananaLeaf width={65} />
      </div>
      <div className="absolute right-0 top-1/4 opacity-15 pointer-events-none hidden lg:block animate-float-slow" style={{ animationDelay: "0.5s" }}>
        <BananaLeaf width={65} flipped />
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-12 scroll-reveal">
          <p style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.35em",
            color: "rgba(26,58,42,0.45)",
            textTransform: "uppercase",
            marginBottom: "10px",
          }}>
            With blessings of their families
          </p>
          <h2 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(28px, 6vw, 42px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "16px",
          }}>
            The Couple
          </h2>
          <div className="flex justify-center">
            <LotusDivider width={240} />
          </div>
        </div>

        {/* Elephant decoration */}
        <div className="flex justify-center mb-10 scroll-reveal" style={{ animationDelay: "0.2s" }}>
          <div className="opacity-20 animate-float" style={{ animationDelay: "2s" }}>
            <Elephant width={90} />
          </div>
        </div>

        {/* Two cards */}
        <div
          className="flex flex-wrap justify-center gap-8 md:gap-16 mb-14"
          style={{ alignItems: "flex-start" }}
        >
          <PersonCard
            name={COUPLE.groom}
            fullName={COUPLE.groomFull}
            familyDesc={COUPLE.groomFamilyDesc}
            isGroom={true}
            delay="0.2s"
          />

          {/* And divider */}
          <div
            className="self-center scroll-reveal hidden md:flex flex-col items-center gap-3"
            style={{ animationDelay: "0.35s" }}
          >
            <div style={{ width: "1px", height: "60px", background: "rgba(212,160,23,0.4)" }} />
            <span style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "28px",
              color: "#d4a017",
              fontStyle: "italic",
              lineHeight: 1,
              background: "linear-gradient(135deg, #d4a017, #f5d78e, #b8860b)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              &amp;
            </span>
            <div style={{ width: "1px", height: "60px", background: "rgba(212,160,23,0.4)" }} />
          </div>

          {/* Mobile &  divider */}
          <div
            className="w-full flex md:hidden justify-center scroll-reveal"
            style={{ animationDelay: "0.3s" }}
          >
            <span style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "32px",
              color: "#d4a017",
              fontStyle: "italic",
              background: "linear-gradient(135deg, #d4a017, #f5d78e, #b8860b)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              &amp;
            </span>
          </div>

          <PersonCard
            name={COUPLE.bride}
            fullName={COUPLE.brideFull}
            familyDesc={COUPLE.brideFamilyDesc}
            isGroom={false}
            delay="0.4s"
          />
        </div>

        {/* Family blessing text */}
        <div className="text-center scroll-reveal" style={{ animationDelay: "0.5s" }}>
          <div
            className="inline-block relative px-8 py-5"
            style={{
              border: "1.5px solid rgba(212,160,23,0.35)",
              background: "rgba(255,255,255,0.3)",
              maxWidth: "500px",
            }}
          >
            <div className="absolute top-0 left-0"><FloralCorner size={28} /></div>
            <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={28} /></div>
            <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={28} /></div>
            <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={28} /></div>
            <p style={{
              fontFamily: "EB Garamond, serif",
              fontStyle: "italic",
              fontSize: "clamp(14px, 3.2vw, 17px)",
              color: "rgba(26,58,42,0.65)",
              lineHeight: 1.7,
              letterSpacing: "0.02em",
            }}>
              "Two families, one heart,
              <br/>a lifetime of togetherness begins."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
