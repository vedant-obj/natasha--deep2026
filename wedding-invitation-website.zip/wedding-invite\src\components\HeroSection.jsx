// =====================================================
// HeroSection.jsx — Main hero with couple names & date
// =====================================================
import { useEffect, useRef } from "react";
import {
  FloralCorner, Peacock, BananaLeaf, LotusDivider, OmSymbol, Mandala
} from "./DecorativeElements";
import { COUPLE } from "../weddingData";

export default function HeroSection() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal, .scroll-reveal-left, .scroll-reveal-right");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.15 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen flex items-center justify-center py-20 px-4 paper-texture overflow-hidden"
    >
      {/* Floating banana leaves */}
      <div
        className="absolute left-0 top-10 opacity-25 animate-float-slow pointer-events-none hidden md:block"
        style={{ animationDelay: "0s" }}
      >
        <BananaLeaf width={70} />
      </div>
      <div
        className="absolute right-0 top-16 opacity-25 animate-float pointer-events-none hidden md:block"
        style={{ animationDelay: "2s" }}
      >
        <BananaLeaf width={70} flipped={true} />
      </div>
      <div
        className="absolute left-0 bottom-20 opacity-20 animate-float pointer-events-none hidden lg:block"
        style={{ animationDelay: "1s" }}
      >
        <BananaLeaf width={55} />
      </div>
      <div
        className="absolute right-0 bottom-20 opacity-20 animate-float-slow pointer-events-none hidden lg:block"
        style={{ animationDelay: "3s" }}
      >
        <BananaLeaf width={55} flipped />
      </div>

      {/* Mandala background watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
        <Mandala size={600} color="#1a3a2a" goldColor="#d4a017" />
      </div>

      {/* Main invitation card */}
      <div
        className="relative w-full mx-auto animate-fade-up"
        style={{ maxWidth: "680px" }}
      >
        {/* Outer green border frame */}
        <div className="invitation-border paper-texture-deep relative rounded-sm" style={{ padding: "clamp(16px, 4vw, 40px)" }}>
          {/* Floral corners */}
          <div className="corner-tl"><FloralCorner size={70} /></div>
          <div className="corner-tr"><FloralCorner size={70} /></div>
          <div className="corner-bl"><FloralCorner size={70} /></div>
          <div className="corner-br"><FloralCorner size={70} /></div>

          {/* Inner gold border */}
          <div className="invitation-border-inner rounded-sm relative" style={{ padding: "clamp(16px, 4vw, 36px)" }}>

            {/* Om symbol */}
            <div className="text-center mb-2 scroll-reveal" style={{ animationDelay: "0.1s" }}>
              <OmSymbol size={44} color="#d4a017" />
            </div>

            {/* Hindi blessing */}
            <div className="text-center mb-4 scroll-reveal" style={{ animationDelay: "0.2s" }}>
              <p style={{
                fontFamily: "Noto Serif Devanagari, serif",
                fontSize: "clamp(13px, 3vw, 16px)",
                color: "rgba(26,58,42,0.55)",
                letterSpacing: "0.12em",
              }}>
                ॥ श्री गणेशाय नमः ॥
              </p>
            </div>

            {/* Lotus divider */}
            <div className="flex justify-center mb-6 scroll-reveal" style={{ animationDelay: "0.25s" }}>
              <LotusDivider width={Math.min(300, window.innerWidth - 100)} />
            </div>

            {/* Wedding invitation text */}
            <div className="text-center mb-3 scroll-reveal" style={{ animationDelay: "0.3s" }}>
              <p style={{
                fontFamily: "Cormorant Garamond, serif",
                fontSize: "clamp(11px, 2.5vw, 13px)",
                color: "rgba(26,58,42,0.55)",
                letterSpacing: "0.35em",
                textTransform: "uppercase",
              }}>
                Together with their families
              </p>
            </div>

            {/* Peacock pair flanking names */}
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="opacity-35 hidden sm:block animate-float" style={{ animationDelay: "1s" }}>
                <Peacock width={60} />
              </div>

              {/* Couple names */}
              <div className="text-center flex-1 scroll-reveal" style={{ animationDelay: "0.35s" }}>
                <h1 style={{
                  fontFamily: "Playfair Display, serif",
                  fontSize: "clamp(34px, 9vw, 62px)",
                  fontWeight: 400,
                  fontStyle: "italic",
                  lineHeight: 1.0,
                  background: "linear-gradient(135deg, #1a3a2a 0%, #0f2418 50%, #1a3a2a 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}>
                  {COUPLE.groom}
                </h1>

                <div style={{
                  fontFamily: "Cormorant Garamond, serif",
                  fontSize: "clamp(18px, 4.5vw, 28px)",
                  color: "#d4a017",
                  letterSpacing: "0.12em",
                  margin: "4px 0",
                  background: "linear-gradient(135deg, #d4a017 0%, #f5d78e 50%, #b8860b 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}>
                  weds
                </div>

                <h1 style={{
                  fontFamily: "Playfair Display, serif",
                  fontSize: "clamp(34px, 9vw, 62px)",
                  fontWeight: 400,
                  fontStyle: "italic",
                  lineHeight: 1.0,
                  background: "linear-gradient(135deg, #1a3a2a 0%, #0f2418 50%, #1a3a2a 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}>
                  {COUPLE.bride}
                </h1>
              </div>

              <div className="opacity-35 hidden sm:block animate-float-slow" style={{
                animationDelay: "2.5s", transform: "scaleX(-1)"
              }}>
                <Peacock width={60} />
              </div>
            </div>

            {/* Tagline */}
            <div className="text-center mb-5 scroll-reveal" style={{ animationDelay: "0.45s" }}>
              <p style={{
                fontFamily: "Cormorant Garamond, serif",
                fontStyle: "italic",
                fontSize: "clamp(13px, 3vw, 17px)",
                color: "rgba(26,58,42,0.5)",
                letterSpacing: "0.06em",
              }}>
                ✦ {COUPLE.tagline} ✦
              </p>
            </div>

            {/* Lotus divider */}
            <div className="flex justify-center mb-5 scroll-reveal" style={{ animationDelay: "0.5s" }}>
              <LotusDivider width={Math.min(260, window.innerWidth - 120)} />
            </div>

            {/* Date & Venue block */}
            <div className="text-center scroll-reveal" style={{ animationDelay: "0.55s" }}>
              <p style={{
                fontFamily: "Cormorant Garamond, serif",
                fontSize: "clamp(11px, 2.5vw, 13px)",
                color: "rgba(26,58,42,0.5)",
                letterSpacing: "0.3em",
                textTransform: "uppercase",
                marginBottom: "6px",
              }}>
                Save the Date
              </p>
              <p style={{
                fontFamily: "Playfair Display, serif",
                fontSize: "clamp(15px, 3.8vw, 20px)",
                color: "#1a3a2a",
                fontWeight: 500,
                letterSpacing: "0.04em",
                marginBottom: "6px",
              }}>
                {COUPLE.weddingDate}
              </p>
              <p style={{
                fontFamily: "EB Garamond, serif",
                fontSize: "clamp(13px, 3vw, 15px)",
                color: "rgba(26,58,42,0.6)",
                letterSpacing: "0.06em",
              }}>
                {COUPLE.city}
              </p>
            </div>

            {/* Scroll down cue */}
            <div className="text-center mt-8 scroll-reveal" style={{ animationDelay: "0.7s" }}>
              <a
                href="#couple"
                className="inline-block transition-all duration-300 hover:opacity-80"
                style={{
                  fontFamily: "Cormorant Garamond, serif",
                  fontSize: "11px",
                  letterSpacing: "0.3em",
                  color: "rgba(26,58,42,0.45)",
                  textTransform: "uppercase",
                  textDecoration: "none",
                }}
              >
                ↓ Scroll to explore ↓
              </a>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
}
