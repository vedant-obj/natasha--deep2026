// =====================================================
// Footer.jsx — Elegant closing footer
// =====================================================
import { FloralCorner, LotusDivider, OmSymbol, Peacock, Mandala } from "./DecorativeElements";
import { COUPLE, CONTACT } from "../weddingData";

export default function Footer() {
  return (
    <footer
      className="relative py-16 px-4 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #1a3a2a 0%, #0f2418 60%, #091a10 100%)",
      }}
    >
      {/* Background mandala */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
        <Mandala size={500} color="#faf3e0" goldColor="#d4a017" />
      </div>

      {/* Floating particles */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: `${3 + (i % 3) * 2}px`,
            height: `${3 + (i % 3) * 2}px`,
            background: "rgba(212,160,23,0.25)",
            left: `${8 + i * 11}%`,
            top: `${20 + (i % 4) * 20}%`,
            animation: `float ${5 + i * 0.6}s ease-in-out infinite`,
            animationDelay: `${i * 0.5}s`,
          }}
        />
      ))}

      <div className="relative max-w-3xl mx-auto text-center">
        {/* Top border */}
        <div className="flex justify-center mb-10">
          <div style={{ width: "clamp(200px, 50vw, 320px)" }}>
            <div style={{ height: "1px", background: "linear-gradient(to right, transparent, rgba(212,160,23,0.5), transparent)", marginBottom: "6px" }} />
            <div style={{ height: "1px", background: "linear-gradient(to right, transparent, rgba(212,160,23,0.25), transparent)" }} />
          </div>
        </div>

        {/* Peacock pair */}
        <div className="flex justify-center gap-8 mb-6">
          <div className="opacity-30 animate-float" style={{ animationDelay: "0.5s" }}>
            <Peacock width={60} color="#faf3e0" goldColor="#d4a017" />
          </div>
          <div className="opacity-30 animate-float-slow" style={{ animationDelay: "2s", transform: "scaleX(-1)" }}>
            <Peacock width={60} color="#faf3e0" goldColor="#d4a017" />
          </div>
        </div>

        {/* Om */}
        <div className="flex justify-center mb-5">
          <OmSymbol size={48} color="#d4a017" />
        </div>

        {/* Main text */}
        <p style={{
          fontFamily: "Cormorant Garamond, serif",
          fontSize: "clamp(11px, 2.5vw, 13px)",
          letterSpacing: "0.35em",
          color: "rgba(212,160,23,0.55)",
          textTransform: "uppercase",
          marginBottom: "12px",
        }}>
          We look forward to celebrating with you
        </p>

        <h2 style={{
          fontFamily: "Playfair Display, serif",
          fontStyle: "italic",
          fontSize: "clamp(28px, 6vw, 44px)",
          fontWeight: 400,
          color: "#faf3e0",
          lineHeight: 1.15,
          marginBottom: "6px",
        }}>
          {COUPLE.groom}
        </h2>
        <div style={{
          fontFamily: "Cormorant Garamond, serif",
          fontSize: "clamp(16px, 3.5vw, 22px)",
          background: "linear-gradient(135deg, #d4a017, #f5d78e, #b8860b)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          marginBottom: "6px",
          letterSpacing: "0.1em",
        }}>
          &amp;
        </div>
        <h2 style={{
          fontFamily: "Playfair Display, serif",
          fontStyle: "italic",
          fontSize: "clamp(28px, 6vw, 44px)",
          fontWeight: 400,
          color: "#faf3e0",
          lineHeight: 1.15,
          marginBottom: "20px",
        }}>
          {COUPLE.bride}
        </h2>

        {/* Lotus divider */}
        <div className="flex justify-center mb-8">
          <LotusDivider width={200} color="#faf3e0" goldColor="#d4a017" />
        </div>

        {/* Wedding date */}
        <p style={{
          fontFamily: "Cormorant Garamond, serif",
          fontSize: "clamp(13px, 3vw, 15px)",
          color: "rgba(212,160,23,0.65)",
          letterSpacing: "0.1em",
          marginBottom: "8px",
        }}>
          {COUPLE.weddingDate}
        </p>
        <p style={{
          fontFamily: "EB Garamond, serif",
          fontStyle: "italic",
          fontSize: "clamp(12px, 2.5vw, 14px)",
          color: "rgba(250,243,224,0.35)",
          letterSpacing: "0.05em",
          marginBottom: "24px",
        }}>
          {COUPLE.city}
        </p>

        {/* Contact */}
        <div className="flex flex-wrap justify-center gap-6 mb-10">
          <a
            href={`tel:${CONTACT.phone}`}
            style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "12px",
              letterSpacing: "0.15em",
              color: "rgba(212,160,23,0.5)",
              textDecoration: "none",
              transition: "color 0.3s",
            }}
            onMouseEnter={e => e.currentTarget.style.color = "#d4a017"}
            onMouseLeave={e => e.currentTarget.style.color = "rgba(212,160,23,0.5)"}
          >
            📞 {CONTACT.phone}
          </a>
          <a
            href={`mailto:${CONTACT.email}`}
            style={{
              fontFamily: "Cormorant Garamond, serif",
              fontSize: "12px",
              letterSpacing: "0.15em",
              color: "rgba(212,160,23,0.5)",
              textDecoration: "none",
              transition: "color 0.3s",
            }}
            onMouseEnter={e => e.currentTarget.style.color = "#d4a017"}
            onMouseLeave={e => e.currentTarget.style.color = "rgba(212,160,23,0.5)"}
          >
            ✉ {CONTACT.email}
          </a>
        </div>

        {/* Navigation quick links */}
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          {["#hero","#couple","#events","#timeline","#gallery","#rsvp"].map((href, i) => {
            const labels = ["Home","Couple","Events","Timeline","Gallery","RSVP"];
            return (
              <a
                key={i}
                href={href}
                style={{
                  fontFamily: "Cormorant Garamond, serif",
                  fontSize: "11px",
                  letterSpacing: "0.25em",
                  textTransform: "uppercase",
                  color: "rgba(250,243,224,0.3)",
                  textDecoration: "none",
                  transition: "color 0.3s",
                }}
                onMouseEnter={e => e.currentTarget.style.color = "rgba(212,160,23,0.7)"}
                onMouseLeave={e => e.currentTarget.style.color = "rgba(250,243,224,0.3)"}
              >
                {labels[i]}
              </a>
            );
          })}
        </div>

        {/* Bottom */}
        <div style={{ height: "1px", background: "linear-gradient(to right, transparent, rgba(212,160,23,0.2), transparent)", marginBottom: "16px" }} />
        <p style={{
          fontFamily: "EB Garamond, serif",
          fontStyle: "italic",
          fontSize: "11px",
          color: "rgba(250,243,224,0.2)",
          letterSpacing: "0.05em",
        }}>
          Made with love ✦ {COUPLE.groomFull} &amp; {COUPLE.brideFull}
        </p>

        {/* Hindi closing blessing */}
        <p style={{
          fontFamily: "Noto Serif Devanagari, serif",
          fontSize: "18px",
          color: "rgba(212,160,23,0.2)",
          marginTop: "8px",
          letterSpacing: "0.08em",
        }}>
          ॐ तत् सत्
        </p>
      </div>
    </footer>
  );
}
