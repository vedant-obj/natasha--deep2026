// =====================================================
// GallerySection.jsx — Photo gallery with card frames
// ✏️ EDIT: Replace placeholder content with real images
// =====================================================
import { useEffect, useRef } from "react";
import { FloralCorner, LotusDivider, BananaLeaf } from "./DecorativeElements";

// ✏️ EDIT: Replace these with actual image paths or URLs
// e.g. { src: "/images/couple1.jpg", caption: "Our first date" }
const GALLERY_ITEMS = [
  { id: 1, caption: "The Beginning", aspectRatio: "4/5" },
  { id: 2, caption: "Together Always", aspectRatio: "3/4" },
  { id: 3, caption: "Our Journey", aspectRatio: "4/5" },
  { id: 4, caption: "In Love", aspectRatio: "3/4" },
  { id: 5, caption: "Cherished Moments", aspectRatio: "4/5" },
  { id: 6, caption: "Forever", aspectRatio: "3/4" },
];

const GalleryCard = ({ item, index }) => (
  <div
    className="scroll-reveal"
    style={{
      animationDelay: `${index * 0.1}s`,
      flex: "1 1 200px",
      maxWidth: "260px",
    }}
  >
    <div
      style={{
        border: "2px solid #1a3a2a",
        borderRadius: "2px",
        padding: "8px",
        background: "#f5ebd0",
        boxShadow: "inset 0 0 0 2.5px #f5ebd0, inset 0 0 0 4px rgba(212,160,23,0.35), inset 0 0 0 5.5px #f5ebd0, 0 6px 24px rgba(26,58,42,0.1)",
        position: "relative",
      }}
    >
      {/* Corner ornaments */}
      <div className="absolute top-0 left-0"><FloralCorner size={26} /></div>
      <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={26} /></div>
      <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={26} /></div>
      <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={26} /></div>

      {/* Image area */}
      <div
        style={{
          aspectRatio: item.aspectRatio,
          background: "linear-gradient(145deg, #e8d5a8 0%, #f0e0b8 50%, #e0c890 100%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "8px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Watermark-style SVG placeholder */}
        <svg
          width="48"
          height="48"
          viewBox="0 0 48 48"
          fill="none"
          style={{ opacity: 0.3 }}
        >
          <rect x="4" y="4" width="40" height="40" rx="2" stroke="#1a3a2a" strokeWidth="1.5"/>
          <circle cx="16" cy="16" r="5" stroke="#1a3a2a" strokeWidth="1.5"/>
          <path d="M4 32 L14 22 L24 30 L32 20 L44 34" stroke="#1a3a2a" strokeWidth="1.5" fill="none"/>
        </svg>
        <p style={{
          fontFamily: "Cormorant Garamond, serif",
          fontSize: "10px",
          letterSpacing: "0.2em",
          color: "rgba(26,58,42,0.35)",
          textTransform: "uppercase",
          textAlign: "center",
          padding: "0 12px",
        }}>
          {/* ✏️ EDIT: Replace with <img src={item.src} alt={item.caption} className="w-full h-full object-cover" /> */}
          Photo Placeholder
        </p>
      </div>

      {/* Caption */}
      <p
        className="text-center mt-2"
        style={{
          fontFamily: "Cormorant Garamond, serif",
          fontStyle: "italic",
          fontSize: "12px",
          color: "rgba(26,58,42,0.55)",
          letterSpacing: "0.08em",
          padding: "0 4px 4px",
        }}
      >
        {item.caption}
      </p>
    </div>
  </div>
);

export default function GallerySection() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.08 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="gallery"
      className="relative py-20 px-4 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #f5ebd0 0%, #faf3e0 100%)",
      }}
    >
      {/* Side leaves */}
      <div className="absolute left-0 bottom-10 opacity-10 pointer-events-none hidden xl:block animate-float" style={{ animationDelay: "1s" }}>
        <BananaLeaf width={60} />
      </div>
      <div className="absolute right-0 top-10 opacity-10 pointer-events-none hidden xl:block animate-float-slow" style={{ animationDelay: "2.5s" }}>
        <BananaLeaf width={60} flipped />
      </div>

      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 scroll-reveal">
          <p style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.35em",
            color: "rgba(26,58,42,0.45)",
            textTransform: "uppercase",
            marginBottom: "10px",
          }}>
            Memories in the making
          </p>
          <h2 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(28px, 6vw, 42px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "16px",
          }}>
            Our Gallery
          </h2>
          <div className="flex justify-center mb-4">
            <LotusDivider width={220} />
          </div>
          <p style={{
            fontFamily: "EB Garamond, serif",
            fontStyle: "italic",
            fontSize: "clamp(13px, 3vw, 15px)",
            color: "rgba(26,58,42,0.45)",
          }}>
            A glimpse into our beautiful journey together
          </p>
        </div>

        {/* Gallery grid */}
        <div className="flex flex-wrap justify-center gap-5">
          {GALLERY_ITEMS.map((item, index) => (
            <GalleryCard key={item.id} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
