// =====================================================
// RSVPSection.jsx — RSVP form with localStorage
// =====================================================
import { useState, useEffect, useRef } from "react";
import { FloralCorner, LotusDivider, OmSymbol, BananaLeaf } from "./DecorativeElements";
import { COUPLE } from "../weddingData";

const initialForm = {
  name: "",
  attendance: "",
  guests: "1",
  message: "",
};

export default function RSVPSection() {
  const [form, setForm] = useState(initialForm);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const sectionRef = useRef(null);

  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) { setError("Please enter your name."); return; }
    if (!form.attendance) { setError("Please select your attendance."); return; }

    // Save to localStorage
    const existing = JSON.parse(localStorage.getItem("wedding_rsvp") || "[]");
    const entry = {
      ...form,
      submittedAt: new Date().toISOString(),
      id: Date.now(),
    };
    localStorage.setItem("wedding_rsvp", JSON.stringify([...existing, entry]));
    setSubmitted(true);
  };

  return (
    <section
      ref={sectionRef}
      id="rsvp"
      className="relative py-20 px-4 paper-texture overflow-hidden"
    >
      {/* Background banana leaves */}
      <div className="absolute left-0 top-1/3 opacity-12 pointer-events-none hidden xl:block animate-float" style={{ animationDelay: "0.5s" }}>
        <BananaLeaf width={60} />
      </div>
      <div className="absolute right-0 bottom-1/3 opacity-12 pointer-events-none hidden xl:block animate-float-slow" style={{ animationDelay: "1.5s" }}>
        <BananaLeaf width={60} flipped />
      </div>

      <div className="max-w-xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10 scroll-reveal">
          <p style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.35em",
            color: "rgba(26,58,42,0.45)",
            textTransform: "uppercase",
            marginBottom: "10px",
          }}>
            Kindly respond by 1st February 2026
          </p>
          <h2 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(28px, 6vw, 42px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "16px",
          }}>
            RSVP
          </h2>
          <div className="flex justify-center">
            <LotusDivider width={220} />
          </div>
        </div>

        {/* Form card */}
        <div
          className="event-card-insert scroll-reveal"
          style={{ animationDelay: "0.2s", borderRadius: "3px", maxWidth: "540px", margin: "0 auto" }}
        >
          {/* Top band */}
          <div style={{ height: "6px", background: "linear-gradient(90deg, transparent, rgba(212,160,23,0.5), transparent)" }} />

          <div className="relative p-7">
            {/* Corners */}
            <div className="absolute top-0 left-0"><FloralCorner size={44} /></div>
            <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={44} /></div>
            <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={44} /></div>
            <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={44} /></div>

            {!submitted ? (
              <>
                <div className="text-center mb-6">
                  <OmSymbol size={32} color="#d4a017" />
                  <p style={{
                    fontFamily: "EB Garamond, serif",
                    fontStyle: "italic",
                    fontSize: "clamp(13px, 3vw, 15px)",
                    color: "rgba(26,58,42,0.55)",
                    marginTop: "8px",
                  }}>
                    Your presence is our greatest joy
                  </p>
                </div>

                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                  {/* Name */}
                  <div>
                    <label style={{
                      display: "block",
                      fontFamily: "Cormorant Garamond, serif",
                      fontSize: "11px",
                      letterSpacing: "0.25em",
                      color: "rgba(26,58,42,0.6)",
                      textTransform: "uppercase",
                      marginBottom: "6px",
                    }}>
                      Your Full Name *
                    </label>
                    <input
                      className="rsvp-input"
                      type="text"
                      name="name"
                      placeholder="e.g. Rahul & Deepika Verma"
                      value={form.name}
                      onChange={handleChange}
                      autoComplete="name"
                    />
                  </div>

                  {/* Attendance */}
                  <div>
                    <label style={{
                      display: "block",
                      fontFamily: "Cormorant Garamond, serif",
                      fontSize: "11px",
                      letterSpacing: "0.25em",
                      color: "rgba(26,58,42,0.6)",
                      textTransform: "uppercase",
                      marginBottom: "6px",
                    }}>
                      Will you be joining us? *
                    </label>
                    <select
                      className="rsvp-input"
                      name="attendance"
                      value={form.attendance}
                      onChange={handleChange}
                      style={{ cursor: "pointer" }}
                    >
                      <option value="">— Please select —</option>
                      <option value="yes_all">Joyfully attending all events</option>
                      <option value="yes_wedding">Attending the Wedding &amp; Reception only</option>
                      <option value="yes_some">Attending select events</option>
                      <option value="no">Unable to attend</option>
                    </select>
                  </div>

                  {/* Number of guests */}
                  <div>
                    <label style={{
                      display: "block",
                      fontFamily: "Cormorant Garamond, serif",
                      fontSize: "11px",
                      letterSpacing: "0.25em",
                      color: "rgba(26,58,42,0.6)",
                      textTransform: "uppercase",
                      marginBottom: "6px",
                    }}>
                      Number of Guests
                    </label>
                    <select
                      className="rsvp-input"
                      name="guests"
                      value={form.guests}
                      onChange={handleChange}
                      style={{ cursor: "pointer" }}
                    >
                      {[1,2,3,4,5,6,7,8].map(n => (
                        <option key={n} value={String(n)}>{n} {n === 1 ? "guest" : "guests"}</option>
                      ))}
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label style={{
                      display: "block",
                      fontFamily: "Cormorant Garamond, serif",
                      fontSize: "11px",
                      letterSpacing: "0.25em",
                      color: "rgba(26,58,42,0.6)",
                      textTransform: "uppercase",
                      marginBottom: "6px",
                    }}>
                      A Message for the Couple
                    </label>
                    <textarea
                      className="rsvp-input"
                      name="message"
                      rows="3"
                      placeholder="Share your blessings or wishes..."
                      value={form.message}
                      onChange={handleChange}
                      style={{ resize: "vertical" }}
                    />
                  </div>

                  {/* Error */}
                  {error && (
                    <p style={{
                      fontFamily: "EB Garamond, serif",
                      fontSize: "13px",
                      color: "#8b1a2a",
                      textAlign: "center",
                      fontStyle: "italic",
                    }}>
                      {error}
                    </p>
                  )}

                  {/* Submit button */}
                  <button
                    type="submit"
                    className="transition-all duration-300"
                    style={{
                      fontFamily: "Cormorant Garamond, serif",
                      fontSize: "12px",
                      letterSpacing: "0.3em",
                      textTransform: "uppercase",
                      color: "#faf3e0",
                      background: "#1a3a2a",
                      border: "1.5px solid rgba(212,160,23,0.4)",
                      padding: "13px 24px",
                      borderRadius: "2px",
                      cursor: "pointer",
                      width: "100%",
                      marginTop: "4px",
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.background = "#0f2418";
                      e.currentTarget.style.borderColor = "#d4a017";
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.background = "#1a3a2a";
                      e.currentTarget.style.borderColor = "rgba(212,160,23,0.4)";
                    }}
                  >
                    ✦ Send RSVP ✦
                  </button>
                </form>
              </>
            ) : (
              /* Success state */
              <div className="text-center py-8 animate-fade-up">
                <div className="text-4xl mb-4">🌸</div>
                <h3 style={{
                  fontFamily: "Playfair Display, serif",
                  fontStyle: "italic",
                  fontSize: "clamp(22px, 5vw, 30px)",
                  fontWeight: 400,
                  color: "#0f2418",
                  marginBottom: "12px",
                }}>
                  Thank You, {form.name.split(" ")[0]}!
                </h3>
                <div className="flex justify-center mb-4">
                  <LotusDivider width={180} />
                </div>
                <p style={{
                  fontFamily: "EB Garamond, serif",
                  fontStyle: "italic",
                  fontSize: "clamp(14px, 3vw, 16px)",
                  color: "rgba(26,58,42,0.6)",
                  lineHeight: 1.7,
                  maxWidth: "320px",
                  margin: "0 auto",
                }}>
                  Your response has been received. {COUPLE.groom} &amp; {COUPLE.bride} look forward to celebrating with you!
                </p>
                <p className="mt-4" style={{
                  fontFamily: "Noto Serif Devanagari, serif",
                  fontSize: "20px",
                  color: "#d4a017",
                  opacity: 0.7,
                }}>
                  ॐ शान्तिः
                </p>
              </div>
            )}
          </div>

          {/* Bottom band */}
          <div style={{ height: "6px", background: "linear-gradient(90deg, transparent, rgba(212,160,23,0.5), transparent)" }} />
        </div>
      </div>
    </section>
  );
}
