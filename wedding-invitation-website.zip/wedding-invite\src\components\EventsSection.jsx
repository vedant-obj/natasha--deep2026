// =====================================================
// EventsSection.jsx — Individual event insert cards
// Mehendi, Sangeet, Haldi, Wedding, Reception
// =====================================================
import { useEffect, useRef } from "react";
import { FloralCorner, LotusDivider, BananaLeaf } from "./DecorativeElements";
import { EVENTS } from "../weddingData";

// ── Maps icon ─────────────────────────────────────────────────────
const MapPinIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M7 1C4.79 1 3 2.79 3 5c0 3.25 4 8 4 8s4-4.75 4-8c0-2.21-1.79-4-4-4zm0 5.5A1.5 1.5 0 1 1 7 3a1.5 1.5 0 0 1 0 3z" fill="currentColor"/>
  </svg>
);

const ClockIcon = () => (
  <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
    <circle cx="6.5" cy="6.5" r="5.5" stroke="currentColor" strokeWidth="1.2"/>
    <line x1="6.5" y1="3.5" x2="6.5" y2="6.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
    <line x1="6.5" y1="6.5" x2="8.5" y2="8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
  </svg>
);

const CalendarIcon = () => (
  <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
    <rect x="1" y="2.5" width="11" height="10" rx="1.5" stroke="currentColor" strokeWidth="1.2"/>
    <line x1="4" y1="1" x2="4" y2="4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
    <line x1="9" y1="1" x2="9" y2="4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
    <line x1="1" y1="6" x2="12" y2="6" stroke="currentColor" strokeWidth="0.8"/>
  </svg>
);

// ── Single Event Card ─────────────────────────────────────────────
const EventCard = ({ event, index }) => {
  const isEven = index % 2 === 0;

  return (
    <div
      className="scroll-reveal event-card-insert"
      style={{
        animationDelay: `${index * 0.12}s`,
        borderRadius: "3px",
        maxWidth: "340px",
        width: "100%",
        transform: "translateY(60px)",
        transition: `opacity 0.8s ease ${index * 0.1}s, transform 0.8s cubic-bezier(0.34,1.4,0.64,1) ${index * 0.1}s`,
      }}
    >
      {/* Top decorative band */}
      <div
        style={{
          height: "6px",
          background: `linear-gradient(90deg, transparent, ${event.accentColor}55, ${event.accentColor}88, ${event.accentColor}55, transparent)`,
        }}
      />

      <div className="relative p-6">
        {/* Corner ornaments */}
        <div className="absolute top-0 left-0"><FloralCorner size={38} /></div>
        <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={38} /></div>

        {/* Event icon */}
        <div className="text-center mb-2">
          <span style={{ fontSize: "28px" }}>{event.icon}</span>
        </div>

        {/* Event title */}
        <h3
          className="text-center mb-1"
          style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(20px, 4.5vw, 26px)",
            fontWeight: 400,
            color: "#0f2418",
            letterSpacing: "0.02em",
          }}
        >
          {event.title}
        </h3>

        {/* Gold dot row */}
        <div className="flex justify-center gap-1 mb-3">
          {[0,1,2].map(i => (
            <div
              key={i}
              style={{
                width: "4px",
                height: "4px",
                borderRadius: "50%",
                background: "#d4a017",
                opacity: i === 1 ? 0.8 : 0.4,
              }}
            />
          ))}
        </div>

        {/* Description */}
        <p
          className="text-center mb-4"
          style={{
            fontFamily: "EB Garamond, serif",
            fontStyle: "italic",
            fontSize: "clamp(12px, 2.8vw, 14px)",
            color: "rgba(26,58,42,0.6)",
            lineHeight: 1.65,
            letterSpacing: "0.02em",
          }}
        >
          {event.description}
        </p>

        {/* Divider */}
        <div className="flex justify-center mb-4">
          <LotusDivider width={180} />
        </div>

        {/* Details */}
        <div className="space-y-2 mb-4">
          <div className="flex items-start gap-2" style={{ color: "rgba(26,58,42,0.65)" }}>
            <span className="mt-0.5 shrink-0" style={{ color: "#d4a017" }}><CalendarIcon /></span>
            <span style={{ fontFamily: "EB Garamond, serif", fontSize: "clamp(12px,2.8vw,14px)" }}>
              {event.date}
            </span>
          </div>
          <div className="flex items-start gap-2" style={{ color: "rgba(26,58,42,0.65)" }}>
            <span className="mt-0.5 shrink-0" style={{ color: "#d4a017" }}><ClockIcon /></span>
            <span style={{ fontFamily: "EB Garamond, serif", fontSize: "clamp(12px,2.8vw,14px)" }}>
              {event.time}
            </span>
          </div>
          <div className="flex items-start gap-2" style={{ color: "rgba(26,58,42,0.65)" }}>
            <span className="mt-0.5 shrink-0" style={{ color: "#d4a017" }}><MapPinIcon /></span>
            <div>
              <p style={{ fontFamily: "EB Garamond, serif", fontSize: "clamp(12px,2.8vw,14px)", fontWeight: 500, color: "#1a3a2a" }}>
                {event.venue}
              </p>
              <p style={{ fontFamily: "EB Garamond, serif", fontSize: "clamp(11px,2.5vw,13px)", color: "rgba(26,58,42,0.5)" }}>
                {event.address}
              </p>
            </div>
          </div>
        </div>

        {/* Google Maps button */}
        <a
          href={event.mapsLink}
          target="_blank"
          rel="noopener noreferrer"
          className="block text-center transition-all duration-300"
          style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.25em",
            textTransform: "uppercase",
            color: "#faf3e0",
            background: "#1a3a2a",
            border: "1.5px solid rgba(212,160,23,0.4)",
            padding: "9px 16px",
            borderRadius: "2px",
            textDecoration: "none",
            display: "block",
          }}
          onMouseEnter={e => {
            e.currentTarget.style.background = "#0f2418";
            e.currentTarget.style.borderColor = "#d4a017";
          }}
          onMouseLeave={e => {
            e.currentTarget.style.background = "#1a3a2a";
            e.currentTarget.style.borderColor = "rgba(212,160,23,0.4)";
          }}
        >
          ✦ Get Directions ✦
        </a>

        {/* Bottom corners */}
        <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={38} /></div>
        <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={38} /></div>
      </div>

      {/* Bottom decorative band */}
      <div
        style={{
          height: "6px",
          background: `linear-gradient(90deg, transparent, ${event.accentColor}55, ${event.accentColor}88, ${event.accentColor}55, transparent)`,
        }}
      />
    </div>
  );
};

// ── Main Section ──────────────────────────────────────────────────
export default function EventsSection() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(e => {
          if (e.isIntersecting) {
            e.target.classList.add("visible");
            e.target.style.transform = "translateY(0)";
            e.target.style.opacity = "1";
          }
        });
      },
      { threshold: 0.08 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="events"
      className="relative py-20 px-4 overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #faf3e0 0%, #f5ebd0 50%, #faf3e0 100%)",
      }}
    >
      {/* Side leaves */}
      <div className="absolute left-0 top-20 opacity-12 pointer-events-none hidden xl:block animate-float-slow" style={{ animationDelay: "0.8s" }}>
        <BananaLeaf width={55} />
      </div>
      <div className="absolute right-0 bottom-20 opacity-12 pointer-events-none hidden xl:block animate-float" style={{ animationDelay: "2s" }}>
        <BananaLeaf width={55} flipped />
      </div>

      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-14 scroll-reveal">
          <p style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.35em",
            color: "rgba(26,58,42,0.45)",
            textTransform: "uppercase",
            marginBottom: "10px",
          }}>
            Join us in celebration
          </p>
          <h2 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(28px, 6vw, 42px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "16px",
          }}>
            Events &amp; Celebrations
          </h2>
          <div className="flex justify-center">
            <LotusDivider width={240} />
          </div>
          <p style={{
            fontFamily: "EB Garamond, serif",
            fontStyle: "italic",
            fontSize: "clamp(14px, 3vw, 16px)",
            color: "rgba(26,58,42,0.5)",
            marginTop: "12px",
          }}>
            We joyfully invite you to be part of every ritual
          </p>
        </div>

        {/* Cards grid */}
        <div
          className="flex flex-wrap justify-center gap-6"
          style={{ alignItems: "stretch" }}
        >
          {EVENTS.map((event, index) => (
            <EventCard key={event.id} event={event} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
